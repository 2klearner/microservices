package com.mphasis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class Bookservice {

	@Autowired
	private RestTemplate restTemplate;
	
	@CircuitBreaker(name = "book-service",fallbackMethod = "fallbackMethodGetBookById")
	public Book getBookById(int id) {
		
	  Book book=restTemplate.getForObject("http://book-service/books/" + id, Book.class);
	  return book;
	}
	
	public Book fallbackMethodGetBookById(int id, Throwable cause) {
		System.out.println("Exception Raised with Message: ===> "+ cause.getMessage());
		return new Book(id ,"Stories Book" ,"XYZ" ,123456 ,300 ,2024);
	}
}
