package com.mphasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BookstoreappConsumerEurekaRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreappConsumerEurekaRibbonApplication.class, args);
		System.out.println("started...");
	}

}
