package com.mphasis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class Bookservice {

	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "fallbackMethodGetBookById")
	public Book getBookById(int id) {
		
	  Book book=restTemplate.getForObject("http://book-service/books/" + id, Book.class);
	  return book;
	}
	
	public Book fallbackMethodGetBookById(int id) {
		return new Book(id ,"Stories Book" ,"XYZ" ,123456 ,300 ,2024);
	}
}
