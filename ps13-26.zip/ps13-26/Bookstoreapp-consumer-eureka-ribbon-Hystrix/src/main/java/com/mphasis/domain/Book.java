package com.mphasis.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data

@NoArgsConstructor
@AllArgsConstructor

public class Book {

	private Integer id;
	private String bookTitle;
	private String bookPublisher;	
	private double isbn;
	private Integer page;
	private int year;


	
	
	
	
	

}