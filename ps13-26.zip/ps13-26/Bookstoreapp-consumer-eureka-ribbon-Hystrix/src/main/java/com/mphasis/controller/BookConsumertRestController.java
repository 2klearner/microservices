package com.mphasis.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Book;
import com.mphasis.service.Bookservice;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@Scope("request")
public class BookConsumertRestController {
	
	@Autowired
	private Bookservice bookService;
	@GetMapping("/get-books/{id}")
	
	@HystrixCommand(fallbackMethod = "fallbackGetBookById")
	public Book getBookById(@PathVariable int id) {
		return bookService.getBookById(id);
	}
	
	
	public Book fallbackGetBookById(int id) {

		Book book = new Book();
        book.setBookTitle("Java");
        book.setBookPublisher("Karthik");
        book.setIsbn(1234567890); // Set a valid ISBN
        book.setPage(200); // Set number of pages
        book.setYear(2023); // Set year
        
        return book;

	}


}