package com.mphasis.ebookstoreapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.mphasis.ebookstoreapp.pojo.Book;
import com.mphasis.ebookstoreapp.service.IBookService;

import brave.sampler.Sampler;

@EnableDiscoveryClient
//@EnableEurekaClient
@SpringBootApplication
public class EbookstoreappApplication implements CommandLineRunner {


	
	
	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
	}

	@Bean
	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	
	@Autowired
	@Qualifier("bookService")
    private IBookService bookService;
    
    @Override
    public void run(String... args) throws Exception {
        // Create a new book object
        Book book = new Book();
        book.setBookTitle("Sample Book");
        book.setBookPublisher("Sample Publisher");
        book.setIsbn(1234567890); // Set a valid ISBN
        book.setPage(200); // Set number of pages
        book.setYear(2023); // Set year

        // Add the book
        bookService.addBook(book);
    }

}
