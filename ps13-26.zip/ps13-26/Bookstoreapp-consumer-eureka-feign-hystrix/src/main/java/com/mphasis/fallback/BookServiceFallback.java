package com.mphasis.fallback;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.mphasis.domain.Book;
import com.mphasis.proxy.BookServiceProxy;

@Component
public class BookServiceFallback implements BookServiceProxy {

	@Override
	public Book getBookById(Integer id) {
		// TODO Auto-generated method stub
		return new Book(id ,"Stories Book" ,"XYZ" ,123456 ,300 ,2024);
        
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return new ArrayList<Book>();
	}

}
