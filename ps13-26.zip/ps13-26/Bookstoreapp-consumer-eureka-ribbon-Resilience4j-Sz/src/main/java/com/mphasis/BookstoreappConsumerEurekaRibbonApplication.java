package com.mphasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import brave.sampler.Sampler;


@SpringBootApplication
public class BookstoreappConsumerEurekaRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreappConsumerEurekaRibbonApplication.class, args);
		System.out.println("started...");
	}

	@Bean
	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
}
