package com.mphasis.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Book;
import com.mphasis.service.Bookservice;

import io.micrometer.core.annotation.Timed;

@RestController
@Scope("request")
public class BookConsumertRestController {
	
	@Autowired
	private Bookservice bookService;
	
	@Timed(value="getBookById.time",description="Time taken to return book")
	@GetMapping("/get-books/{id}")
	
	public Book getBookById(@PathVariable int id) {
		return bookService.getBookById(id);
	}
	

}