package com.mphasis.eBookStoreSpringCloudGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreSpringCloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
