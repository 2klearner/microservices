package com.mphasis.ebookstoreapp.service;

import java.util.List;

import com.mphasis.ebookstoreapp.pojo.Book;


public interface IBookService {

	public Book addBook(Book book);

	public Book updateBook(Book book);

	public List<Book> getAllBooks();

	public Book getBookById(Integer id);

	public void deleteBookById(Integer id);

	public List<Book> findByBookTitle(String title);
	public List<Book> findByBookPublisherLike(String publisher);
	public List<Book> findByYear(int year);
}
