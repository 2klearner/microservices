package com.mphasis.ebookstoreapp.repo;

import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.ebookstoreapp.pojo.Book;


@Repository(value="bookRepository")
@Scope(value="singleton")
public interface BookStoreRepository extends JpaRepository<Book, Integer>{

	List<Book> findByBookTitle(String title);
	List<Book> findByBookPublisherLike(String publisher);
	List<Book> findByYear(int year);
}
