package com.mphasis.ebookstoreapp.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {

	@Id
	@GeneratedValue( strategy=GenerationType.IDENTITY)
	private Integer id;
	
	
	@Column(name="book_title")
	private String bookTitle;

	@Column(name="book_publisher")
	private String bookPublisher;	
	
	@Column(name="book_isbn")
	private double isbn;
	
	@Column(name="book_number_of_pages")
	private Integer page;

	@Column(name="book_year")
	private int year;


	
	
}
